## 2022 캡스톤 2학기

**실행 방법**
```zsh
npm i 

npm run start

```

