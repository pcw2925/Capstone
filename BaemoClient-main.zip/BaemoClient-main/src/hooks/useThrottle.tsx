import { useRef } from "react";

export default function useThrottle() {
  const timer = useRef<any>();
}
